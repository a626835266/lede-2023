/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef lIlIlIIll
#define lIlIlIIll
struct IIllllI{lllII lIlllll;};


#define llIIlIlII			_IO(((char)(0x1776+2830-0x2244)), (0x4c5+5005-0x17b2))
#define IllIIIlII			_IO(((char)(0xbe0+1195-0x104b)), (0xb00+6520-0x23d7))
#define lIIIIIlIl			_IO(((char)(0x54b+609-0x76c)), (0xabf+5654-0x2033))
#define IllllIllI	_IO(((char)(0x343+2770-0xdd5)), (0x1599+2862-0x2024))
#define IlIllIlIl		_IO(((char)(0xd7c+1988-0x1500)), (0xd50+2650-0x1706))
#define IlIllIIlll			_IO(((char)(0x1186+1975-0x18fd)), (0x274+2909-0xd2c))
#define IIIllIIIl				_IO(((char)(0x44+9366-0x249a)), (0x31c+393-0x3ff))
#define IIIlIIlIl	_IO(((char)(0x6b1+1834-0xd9b)), (0x1482+3569-0x21cc))
struct IIlllIIll{struct IIllllI lIIlII;lllII busnum;lllII devnum;};struct 
lIlIlllII{struct IIllllI lIIlII;lllII IIIllIl;};struct lllIllllI{struct IIllllI 
lIIlII;lllII lIIllIl;};struct lIlIIlIll{struct IIllllI lIIlII;};struct 
IIlIIlIlII{struct IIllllI lIIlII;lllII IlIlllIl;};


#define IllIlIIIl	(0xbc1+5776-0x2251)
#define IIlllIlIII		(0x26+4115-0x1038)
#define lIlIlllll		(0x12e5+3499-0x208e)
#define lIllllIII		(0x67a+5644-0x1c83)
#define IlllIlIll		(0xa54+2750-0x150f)






#define IIllllIll						((lIllIl)(0x2d1+3207-0xf58))
#define IIIlIIIII					((lIllIl)(0x225+3550-0x1002))
#define lIIIllIII					((lIllIl)(0x52b+1587-0xb5c))
#define IIIllIlII					((lIllIl)(0xabb+1321-0xfe1))
#define lIIIlIIIl					((lIllIl)-(0x635+3204-0x12b8))
#define lIlIlIIlI		_IO(((char)(0x4a0+1052-0x87c)), (0x16d0+4162-0x265e))
#define llIIllllI		_IO(((char)(0x430+535-0x607)), (0x11d1+279-0x1233))
#define IlIllllIl		_IO(((char)(0x256+3525-0xfdb)), (0x559+7068-0x203f))
struct llIIlllll{struct IIllllI lIIlII;lllII lllllIlII;lIllll llIIIlII;lIllll 
IIIIllll;lIllll IlIIllIl;lIllll IIllIllI;lIllIl lIlIllIII;
};struct IlIllIIll{struct IIllllI lIIlII;lllII lllllIlII;};struct IlIlIIllI{
struct IIllllI lIIlII;};


#define IIIlIIIlll		_IO(((char)(0x822+7826-0x2674)), (0x872+3022-0x1378))
#define IlllIlIIl		_IO(((char)(0x1107+2435-0x1a4a)), (0x101c+2890-0x1a9d))
#define IIIIllllI		_IO(((char)(0x289+6356-0x1b1d)), (0x16a4+3757-0x2487))
#define IIIlIllII		_IO(((char)(0x1598+3862-0x246e)), (0x345+5248-0x16fa))
#define IIllIlIlI		_IO(((char)(0x1038+1793-0x16f9)), (0x451+6246-0x1beb))
#define IIIlIIIIl	_IO(((char)(0x3b4+6786-0x1df6)), (0x396+4839-0x15b0))
#define IIllIIlIl	_IO(((char)(0x68d+7657-0x2436)), (0x4ec+8541-0x257b))
#define IIIlIIlII		_IO(((char)(0x6f+2771-0xb02)), (0xa18+1851-0x1084))
#define IlllIIIII		_IO(((char)(0x1172+67-0x1175)), (0x81d+1635-0xdb0))
struct IlIIlIIlI{struct IIllllI lIIlII;lllII lIIlIIII;
};struct llllIIlIl{struct IIllllI lIIlII;};struct llllIIIlI{struct IIllllI 
lIIlII;lIllIl IlIIIIlIl;char IIllI[(0x1df2+1533-0x23ce)];
};struct llIIIlIII{struct IIllllI lIIlII;lIllIl IlIIIIlI;char IIllI[
(0x22d2+524-0x24bd)];
};struct IllllIIlI{struct IIllllI lIIlII;char IIllI[(0x14c1+709-0x1765)];
};struct IIIlIIIlI{struct IIllllI lIIlII;char IIllI[(0x12af+1159-0x1715)];

};struct IlllllllI{struct IIllllI lIIlII;char IIllI[(0xf7b+5812-0x260e)];

};struct IIlllllll{struct IIllllI lIIlII;lllII lIIlIIII;
};struct IllllllII{struct IIllllI lIIlII;};
#if (0xa4c+1932-0x11d8)
struct IIIIIIlll{struct IIllllI lIIlII;char IIllI[(0x1ea4+315-0x1fbe)];
lIllll llIIIlII;lIllll IIIIllll;lIllll IlIIllIl;lIllll IIllIllI;lIllIl lIIIIIIl;
lIllIl lIlllllI;lIllIl lllIIlII;lIllIl lIlIllIII;
lIllIl lllIIIllII;lIllIl lIIIIllIIl;char IIIlIII[(0xba2+5403-0x1fbd)];char 
serial[(0x86c+1060-0xb90)];char lIIIIlIllI[(0x365+5596-0x1841)];char description
[(0x16e4+2709-0x2079)];};
#endif




#define llllIlIlI			(0x103f+5585-0x260f)
#define IllIllIII			(0xdc4+2362-0x16fc)
#define lIIlllIll			(0x1a87+1091-0x1ec6)
#define lIIllIIIlI		(0xb59+1998-0x131f)
#define lIllllIll	(0x1b5d+2677-0x25c2)
#define IlllIllII	(0xfca+3123-0x1bdd)
#define llIIIlIlI		(0x771+2626-0x1173)
#define IlllllIIl		(0x2044+1275-0x24bf)

#define IlIlIIlII	268435456
#define IIlllllII		536870912
#define llllllIlI		1073741824
typedef struct IIlIIIll{lllII IIlllIl;lllII lllIIIl;lllII lIIllIIl;lllII 
IllIlllI;lIllll llIIIlII;lIllll IIIIllll;lIllll IlIIllIl;lIllIl lIIIIIIl;lIllIl 
lIlllllI;lIllIl lllIIlII;


}lIIlIlIlIl,*lIIlIIlIlI;



#define lIllllIIlI		(0x380+2120-0xbc6)
typedef struct IIllllll{lIllll llIIIlII;lIllll IIIIllll;lllII lIIlIllIl;}
llllIIIIlI,*lIlIlIIIlI;
#endif 

