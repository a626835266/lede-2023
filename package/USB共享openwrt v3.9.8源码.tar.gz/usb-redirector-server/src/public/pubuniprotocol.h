/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef llllIIllI
#define llllIIllI
#include "apitypes.h"
#pragma pack(push,1)
enum{llIIllll=(0xdf6+3790-0x1cc4),
lIlIllll,
llIlllIl,
IIlIlIII,
llIIIIlI,
IIllIIIl,
lllIlIIl,
lIlllIIl,
IIIIlllI,
IIlIIIlI,
llIIIIIIl,IIllIIlI,
llIIlIII,
llIIlIll,
lIIIlllI,
IllIllIIII,
lllIIIlllI,
IlIIIIIIl,};enum{lllllIlIll=(0x109b+5105-0x248c),IIlIllIIlI,IlIllIlII,lIIlIlIII,
llIIlIlll,lllllIllIl,llIlllIIl,IIlIlIIII,IIllIllll,lIllIIIlII,lIIllIlll,
lIlllIIII,IIIllllIll,llIllIlIl,lIIIlIlll,lIllIIIIl,llIllllIl,llIllIIlll};
#define IIIllI 			(0x72+4391-0x1198)
#define lIIlIll 		(0x6bb+1078-0xaef)
#define IlIllIIII          	(0x124d+4112-0x2259)
#define IIlIIIIIII 			(0x1ac1+710-0x1d7f)
typedef struct{union{struct{llIIII IIIlIl:(0xf61+3937-0x1e92);
llIIII IllllII:(0x1b05+846-0x1e43);};llIIII lllIIIIlll;};lllII IIIII;
lllII IIIlIIl;
lllII Status;lllII Context;}__attribute__((packed))IlIllI,*lIIllIlIlI;
#define lIIIIIIIlI	(0x66c+984-0xa44)
#define IlIlIlllI		(0xde0+2085-0x1604)
#define IlIlllIlI			(0x177+1120-0x5d7)
#define IlIIIlIll	(0x889+623-0xaf7)
#define lIIIlllIl	(0xd1d+4657-0x1f4c)
#define lllIIIlII	(0xf05+5557-0x24b7)
typedef union{struct{lIllll IlIlIlII;};struct{lIllll lIIIlIlI:
(0x46d+4085-0x1461);lIllll lIlIllIIIl:(0x599+5242-0x1a12);lIllll llIllIlII:
(0xf86+4348-0x2081);lIllll IlIIIllIl:(0x1b59+110-0x1bc6);lIllll IIIlIlllll:
(0x1c61+1036-0x206c);lIllll lIllIlIII:(0x1e09+1754-0x24e2);lIllll lllIIlIIl:
(0x1636+4231-0x26bb);lIllll lIllIllll:(0x971+5289-0x1e18);lIllll lIlIIIIlIl:
(0x1280+2392-0x1bd6);lIllll IlllIIIlI:(0xcef+5302-0x21a3);lIllll IIllIIIIl:
(0xa4f+4967-0x1db4);};}llIlIllIl,*lIlIlIllII;typedef struct{IlIllI llllll;lIllIl
 IIllIll;
lIllIl llIlIIll;
lIllIl lllllllI;
lIllIl lIlIIlll;lIllll lIIlIIlI;lllII IllllI;}__attribute__((packed))IIIIlIlll,*
IIIlIlIlll;typedef struct{IlIllI llllll;lIllIl lllIllIl;lIllIl IlllllIl;struct{
lIllIl IlIllIl;lIllIl llIlllI;}__attribute__((packed))llIIlII[
(0x18e1+2742-0x2396)];}__attribute__((packed))lIIlllIlI,*lIlIlllIIl;typedef 
struct{IlIllI llllll;lIllIl IlIllIl;lIllIl llIlllI;}__attribute__((packed))
IllIIllll,*IIIIIllIlI;
#define lllllIIIII			(0xaed+7030-0x2663)
#define lIIIlllII				(0x68+7895-0x1f3e)
#define lIllllllI				(0xb03+2892-0x164d)
#define IlIlIIIll			(0x6dc+3912-0x1621)
#define IIIlIlIlI		(0xc58+1065-0x1081)
#define IlllllIlI		(0x1c7d+636-0x1ef8)
#define IIllIIlII		(0x1ecf+1567-0x24ec)
#define llIllIlll			(0xd52+740-0x1033)
#define lIlllllIll			(0x1663+1686-0x1cf8)
#define IllIlIIllI			(0x119b+2900-0x1cef)
typedef struct{IlIllI llllll;lIllIl Endpoint;lIllIl Flags;union{struct{lIllIl 
llIllIIlII:(0x1c81+2035-0x246f);lIllIl IIIlIllIll:(0x1df+9432-0x26b5);lIllIl 
lIlIlIIIII:(0x709+7165-0x2305);}__attribute__((packed))IllllIIIll;lIllIl IIllIll
;}__attribute__((packed));lIllIl IIIIllIII;lIllll IlIlIlII;lIllll IIlIlllIl;
lllII IllllI;}__attribute__((packed))IllIIlIll,*lllIIllIlI;typedef struct{IlIllI
 llllll;lllII IllllI;lIllIl Endpoint;lIllIl Flags;}__attribute__((packed))
IIIlIlllI,*lIIIIlIlll;typedef struct{IlIllI llllll;lllII IllllI;lllII Interval;
lIllIl Endpoint;lIllIl Flags;}__attribute__((packed))lIIllIllI,*IIIlIIlIII;
typedef struct{IlIllI llllll;lIllIl Flags;
lIllIl Endpoint;}__attribute__((packed))IIlllllIl,*lIIIlllllI;typedef struct{
IlIllI llllll;lllII lIlllIIIl;}__attribute__((packed))IlIIIIllll,*IlIlllIIll;
#define IlIlIlll(IIlIl) (sizeof(lIIllIIlI) - sizeof(IllIlIII) + \
			sizeof(IllIlIII)*(IIlIl)->llIll.IIlIlIl)
typedef struct{lllII Offset;lllII Length;lllII Status;}__attribute__((packed))
IllIlIII,*llIIlIlllI;typedef struct{IlIllI llllll;lIllIl Endpoint;lIllIl Flags;
lllII Interval;lllII IIlIlIIl;lllII IIlIlIl;lllII llIIIIIl;lllII IllllI;IllIlIII
 llIIIIl[(0x831+1301-0xd45)];}__attribute__((packed))lIIllIIlI,*llIIIIlIlI;
#define IIllllIllI(IllIIIIII) (sizeof(lIIIlllll)-(0x86f+3026-0x1440)+(IllIIIIII)\
)
#define IlIllIllIl(lIIIlIIII) ((lIIIlIIII)->IlIII.IIIII-(sizeof(lIIIlllll)-\
(0x502+1883-0xc5c)))
typedef struct{IlIllI llllll;lIllIl IIllIIIIII[(0x1324+3922-0x2275)];}
__attribute__((packed))lIIIlllll,*IIIlIlllIl;
#define IIlIlIlIl		(0x337+4259-0x13d9)
#define IllIlIIlI		(0x73b+5072-0x1b09)
typedef struct{IlIllI llllll;lllII IIllIIll;}__attribute__((packed))lllIIIIlI,*
IIIIllIlll;typedef struct{IlIllI llllll;}__attribute__((packed))IIIlIIllI,*
IlllIlIIII;typedef struct{IlIllI llllll;}__attribute__((packed))lllllIlIl,*
IlllIIIlIl;typedef struct{IlIllI llllll;lIllIl Endpoint;lIllIl Flags;}
__attribute__((packed))IIllIllII,*IIlllllIIl;
typedef union{IlIllI IlIII;IIIIlIlll IIlllI;lIIlllIlI lIllIll;IllIIllll IlIIIIl;
IllIIlIll lllIII;IIIlIlllI lllllI;lIIllIllI llIIlI;IIlllllIl lIllIII;IlIIIIllll 
llIllIII;lIIllIIlI llIll;lIIIlllll IIIIIIlIIl;lllIIIIlI lIlIlIll;IIIlIIllI 
lllIIlIII;lllllIlIl llIIlIlIl;IIllIllII IlIlllll;}__attribute__((packed))
llIIIlIlIl,*IIlII;
#pragma pack(pop)
#endif 

