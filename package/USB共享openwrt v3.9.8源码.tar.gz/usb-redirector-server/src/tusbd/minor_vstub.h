/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef IlIIlllIl
#define IlIIlllIl
#ifdef _USBD_ENABLE_VHCI_
#include "cdev.h"
int llllIlIII(struct lIlIIl*lIllI);void lIllllIIl(struct lIlIIl*lIllI);int 
lIllIllII(struct lIlIIl*lIllI);void llllIIlI(struct lIlIIl*lIllI);
#endif 
#endif 

