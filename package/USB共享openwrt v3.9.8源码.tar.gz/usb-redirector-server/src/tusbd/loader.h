/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef IlIlIllIl
#define IlIlIllIl
#ifdef _USBD_ENABLE_STUB_

struct IllIIIll{struct list_head entry;struct IIlIIIll llIlI;};int IIIIlIII(
struct usb_device*IlIIl);void lIlIIIlII(struct list_head*lIlIllII);void IlIIllll
(void);
struct IIlllIlI{struct list_head entry;struct IIllllll lIIlllI;};lllII llIIIllII
(struct usb_device*IlIIl);void lIIIIlIll(struct list_head*IlIlIIlI);void 
IlIIIlIIl(void);
struct IIllIlIl{struct list_head entry;struct usb_device*IlIIl;const char*serial
;const char*IIllI;const char*IIIlIII;};int IIIlIlII(struct usb_device*llIII,
const char**lIlllIlll,const char**llllIIIIl,const char**IIlIllllI);void 
lIlIIIlll(struct usb_device*IlIIl);void IIlIIlIll(void);int IIllIlIIl(struct 
usb_interface*IIIIII);int IllIIIIl(struct usb_device*IlIIl);void IIIIIIII(struct
 usb_device*IlIIl,int IlIIIIlI);struct usb_device*IllIllII(const char*IIllI);
#endif 
#endif 

