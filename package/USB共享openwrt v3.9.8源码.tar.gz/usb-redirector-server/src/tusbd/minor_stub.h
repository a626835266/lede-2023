/*
 *
 *  Copyright (C) 2007-2020 SimplyCore, LLC
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 *
 */

#ifndef lIIllllIl
#define lIIllllIl
#ifdef _USBD_ENABLE_STUB_
#include "cdev.h"
int IIIIIIIII(struct IIlll*IIIll);void IIlIIIIIl(struct IIlll*IIIll);int 
IlIlIIlIl(struct IIlll*IIIll);void IlIlIllll(struct IIlll*IIIll);
#endif 
#endif 

